# 154-Sim-Project
A simulation of disease spread for CSCI 154 at Fresno state
Group Members
Nate Bean 110467545
Steven Nguyen 109933505
Rogelio Romero 108521003
Cristian Vanegas 110253656
Christian Vaughn 109169183

Required libraries
1. Matplotlib
2. numpy
3. Pandas

run using the main.py file since the 154 SimProject.ipynb Jupyter Notebook was having issues with running the simulation.
